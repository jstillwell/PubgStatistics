﻿var userId = 'jbravo01';    //change this to your id
$.ajax({
    method: "GET",
    url: "http://localhost:60518/api/statistics/" + userId
}).done(function (msg) {
    console.info("Data", msg);
});